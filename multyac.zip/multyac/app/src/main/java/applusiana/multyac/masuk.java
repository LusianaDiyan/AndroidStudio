package applusiana.multyac;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by USER on 25/03/2018.
 */

public class masuk extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.masuk);
    }
}

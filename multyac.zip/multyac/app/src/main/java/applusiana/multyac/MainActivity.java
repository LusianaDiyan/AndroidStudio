package applusiana.multyac;

import android.content.Intent;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity{
    EditText etNamaa;
    RadioGroup rgKelass;
    RadioButton rbSd, rbSmp, rbSma, rbTk;
    Button btnOk, btnEXit;
    CheckBox cbSBY, cbGrs, cbPacet, cbMLG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       /* etNamaa = findViewById(R.id.etNama);
        rgKelass = findViewById(R.id.rgKelas);
        rbSd = findViewById(R.id.rbSD);
        rbSmp = findViewById(R.id.rbSMP);
        rbSma = findViewById(R.id.rbSMA);
        rbTk = findViewById(R.id.rbTK);
        cbSBY = findViewById(R.id.cbSby);
        cbGrs = findViewById(R.id.cbGresik);
        cbPacet = findViewById(R.id.cbPct);
        cbMLG = findViewById(R.id.cbMlg);
*/
        btnOk = findViewById(R.id.btnOk);
        btnEXit = findViewById(R.id.btnExit);

       btnOk.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(MainActivity.this, masuk.class);
               startActivity(intent);
           }
       });

       btnEXit.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               finish();
           }
       });
    }
}
